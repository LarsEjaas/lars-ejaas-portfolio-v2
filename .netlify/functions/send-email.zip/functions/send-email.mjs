
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// functions/send-email.mts
import "@netlify/functions";
import { z, ZodError } from "zod";
import nodemailer from "nodemailer";
import hbs from "nodemailer-express-handlebars";
import "nodemailer-express-handlebars";
import { create } from "express-handlebars";
import path from "path";
import dotenv from "dotenv";
import DOMPurify from "dompurify";
import { JSDOM } from "jsdom";
var window = new JSDOM("").window;
var purify = DOMPurify(window);
var UNIQUE_IDENTIFIER = "contact";
var GITHUB_ICON = "github_icon.png";
var LINKEDIN_ICON = "linkedin_icon.png";
var BLUESKY_ICON = "bluesky_icon.png";
var LETTER_ICON = "letter_icon.png";
var WRITE_TO_ME = "write_to_me.png";
var SKRIV_TIL_MIG = "skriv_til_mig.png";
var EJAAS_LOGO_1 = "logo1_email.png";
var EJAAS_LOGO_2 = "logo2_email.png";
var EJAAS_SIGNATURE = "signature.png";
var PROFILE_PIC = "profile.png";
var sanitizedHTML = (dirtyHTML) => purify.sanitize(dirtyHTML, {
  ALLOWED_TAGS: [
    "p",
    "br",
    "b",
    "i",
    "em",
    "strong",
    "span",
    "div",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "ul",
    "ol",
    "li",
    "a",
    "pre",
    "code",
    "blockquote",
    "table",
    "thead",
    "tbody",
    "tr",
    "th",
    "td",
    "hr",
    "small",
    "sub",
    "sup"
  ],
  ALLOWED_ATTR: ["class", "href", "style", "target", "rel", "id"]
});
var REDIRECT_SLUGS = {
  en: {
    success: "message-received",
    error: "message-error"
  },
  da: {
    success: "besked-modtaget",
    error: "besked-fejl"
  }
};
function removeTrailingSlash(url) {
  return url.endsWith("/") ? url.slice(0, -1) : url;
}
var getRedirectUrl = (language, referer, type = "success") => {
  const slug = REDIRECT_SLUGS[language][type];
  if (!referer) {
    return `../${slug}`;
  }
  try {
    const url = new URL(referer);
    const pathSegments = url.pathname.split("/").filter(Boolean);
    pathSegments.pop();
    const newPath = pathSegments.length ? `/${pathSegments.join("/")}/${slug}` : `/${slug}`;
    return `${url.origin}${newPath}`;
  } catch {
    return `../${slug}`;
  }
};
var isNodemailerError = (error) => {
  if (!(error instanceof Error) || !("code" in error) || typeof error.code !== "string") {
    return false;
  }
  const nodemailerErrorCodes = [
    "EENVELOPE",
    "EENVELOPEFORMAT",
    "EENCODE",
    "EMESSAGEID",
    "ETXTBSY",
    "EFILE",
    "ECONNECTION",
    "EAUTH",
    "ENOAUTH",
    "ETLS",
    "ESTARTTLS",
    "EUPGRADE",
    "EENOTFOUND",
    "EENOTEMPTY",
    "EMSGBIG",
    "EINVALIDDATE",
    "ETOOMANYTOS",
    "ETOOMANYMSGS"
  ];
  return nodemailerErrorCodes.includes(error.code);
};
var getErrorMessage = (error, language) => {
  switch (true) {
    case error instanceof ZodError:
      return {
        errorCode: "VALIDATION_ERROR",
        errorMessage: language === "en" ? "One or more fields in the contact form are invalid. Please review your information and try again." : "En eller flere felter i kontaktformularen er ugyldige. Gennemg\xE5 venligst dine oplysninger og pr\xF8v igen."
      };
    case (error instanceof TypeError && error.message.includes("MAIL_USER")):
    case (error instanceof TypeError && error.message.includes("MAIL_PASSWORD")):
      return {
        errorCode: "CONFIG_ERROR",
        errorMessage: language === "en" ? "A technical issue occurred while processing the message. Please try again later." : "Der opstod et teknisk problem under behandlingen af beskeden. Pr\xF8v venligst igen senere."
      };
    case (error instanceof Error && isNodemailerError(error)):
      return {
        errorCode: "EMAIL_ERROR",
        errorMessage: language === "en" ? "There was an issue sending the message. Please try again later." : "Der opstod et problem med at sende beskeden. Pr\xF8v venligst igen senere."
      };
    case (error instanceof Error && error.message.includes("ENOTFOUND")):
      return {
        errorCode: "NETWORK_ERROR",
        errorMessage: language === "en" ? "There was a problem connecting to the email service. Please try sending your message again later." : "Der opstod et problem med at oprette forbindelse til email-tjenesten. Pr\xF8v venligst at sende din besked igen senere."
      };
    default:
      return {
        errorCode: "UNKNOWN_ERROR",
        errorMessage: language === "en" ? "An unexpected issue occurred while submitting the message. Please try again later." : "Der opstod et uventet problem under indsendelsen af beskeden. Pr\xF8v venligst igen senere."
      };
  }
};
var FUNCTION_ENDPOINT = "/.netlify/functions/send-email";
var formDataSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  subject: z.string().min(1, "Subject is required"),
  message: z.string().min(1, "Message is required").transform((val) => sanitizedHTML(val)),
  language: z.enum(["en", "da"], {
    errorMap: () => ({ message: "Language must be either 'en' or 'da'" })
  })
});
var getMailAttachments = (lang, type) => {
  const attachments = [];
  attachments.push(
    {
      filename: LINKEDIN_ICON,
      path: path.resolve(__dirname, `./${LINKEDIN_ICON}`),
      cid: `linkedin@${UNIQUE_IDENTIFIER}`
    },
    {
      filename: GITHUB_ICON,
      path: path.resolve(__dirname, `./${GITHUB_ICON}`),
      cid: `github@${UNIQUE_IDENTIFIER}`
    },
    {
      filename: BLUESKY_ICON,
      path: path.resolve(__dirname, `./${BLUESKY_ICON}`),
      cid: `bluesky@${UNIQUE_IDENTIFIER}`
    },
    {
      filename: LETTER_ICON,
      path: path.resolve(__dirname, `./${LETTER_ICON}`),
      cid: `letter@${UNIQUE_IDENTIFIER}`
    }
  );
  if (type === "notification") {
    attachments.push({
      filename: `${lang === "da" ? SKRIV_TIL_MIG : WRITE_TO_ME}`,
      path: path.resolve(
        __dirname,
        `./${lang === "da" ? SKRIV_TIL_MIG : WRITE_TO_ME}`
      ),
      cid: `write@${UNIQUE_IDENTIFIER}`
    });
  }
  if (type === "confirmation") {
    attachments.push(
      {
        filename: EJAAS_LOGO_1,
        path: path.resolve(__dirname, `./${EJAAS_LOGO_1}`),
        cid: `logo1@${UNIQUE_IDENTIFIER}`
      },
      {
        filename: EJAAS_LOGO_2,
        path: path.resolve(__dirname, `./${EJAAS_LOGO_2}`),
        cid: `logo2@${UNIQUE_IDENTIFIER}`
      },
      {
        filename: PROFILE_PIC,
        path: path.resolve(__dirname, `./${PROFILE_PIC}`),
        cid: `profile@${UNIQUE_IDENTIFIER}`
      },
      {
        filename: EJAAS_SIGNATURE,
        path: path.resolve(__dirname, `./${EJAAS_SIGNATURE}`),
        cid: `signature@${UNIQUE_IDENTIFIER}`
      }
    );
  }
  return attachments;
};
var getFirstName = (fullName) => {
  return fullName.split(" ")[0] || fullName;
};
var parseFormData = async (request) => {
  const formData = await request.formData();
  const data = {};
  formData.forEach((value, key) => {
    if (typeof value === "string") {
      data[key] = value;
    }
  });
  return data;
};
var exphbs = create({
  extname: ".handlebars",
  defaultLayout: false
});
var handlebarsOptions = {
  viewEngine: exphbs,
  viewPath: path.resolve(__dirname, "./"),
  extName: ".handlebars"
};
if (process.env.NODE_ENV !== "production") {
  dotenv.config();
}
var mockTransporter = {
  verify: async () => true,
  use: () => {
  },
  sendMail: async (options) => {
    console.info("Development mode: Email would be sent with:", options);
    return { messageId: "mock-id" };
  }
};
var send_email_default = async (req, context) => {
  const devHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  const site_url = removeTrailingSlash(context.url.origin);
  if (req.headers.get("origin") !== site_url) {
    return new Response(JSON.stringify({ message: "Unauthorized" }), {
      status: 401,
      headers: process.env.NODE_ENV === "development" ? devHeaders : { "content-type": "application/json" }
    });
  }
  let redirectUrl = getRedirectUrl("en", req.headers.get("referer") || "");
  let language = "en";
  if (context.url.pathname !== FUNCTION_ENDPOINT) {
    return new Response(JSON.stringify({ message: "Not Found" }), {
      status: 404,
      headers: process.env.NODE_ENV === "development" ? devHeaders : { "content-type": "application/json" }
    });
  }
  try {
    const formData = await parseFormData(req);
    const parseResult = formDataSchema.safeParse(formData);
    const refererUrl = req.headers.get("referer") || req.headers.get("origin");
    if (!parseResult.success) {
      return new Response(
        JSON.stringify({
          error: "Validation failed",
          details: parseResult.error.errors
        }),
        {
          status: 400,
          headers: process.env.NODE_ENV === "development" ? devHeaders : void 0
        }
      );
    }
    const { data } = parseResult;
    const first_name = getFirstName(data.name);
    const {
      name: sender_name,
      email: sender_email,
      message: sender_message,
      subject: sender_subject,
      language: sender_language
    } = data;
    language = sender_language;
    if (sender_language === "da") {
      redirectUrl = getRedirectUrl("da", refererUrl);
    }
    const createNodeMailerTransporter = () => nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: {
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASSWORD
      }
    });
    const transporter = process.env.NODE_ENV === "production" ? createNodeMailerTransporter() : mockTransporter;
    if (process.env.NODE_ENV === "production") {
      transporter.verify(function(error, success) {
        if (error) {
          console.error(error);
        } else {
          console.info("Server is ready to take our messages:", success);
        }
      });
    }
    const confirmationTemplate = sender_language === "da" ? "mailTemplateDa" : "mailTemplateEn";
    const subject = sender_language === "da" ? "\u{1F388} Tak for din besked!" : "\u{1F388} Thank you for your message!";
    if (process.env.NODE_ENV === "production") {
      transporter.use("compile", hbs(handlebarsOptions));
    }
    const mailConfirmationOptions = {
      from: `Lars \u{1F468}\u200D\u{1F4BB} Ejaas <${process.env.NOREPLY_PRIVATE_EMAIL_USER}>`,
      to: `${sender_name} <${sender_email}>`,
      subject,
      template: confirmationTemplate,
      context: {
        first_name,
        siteURL: site_url,
        linkedIn: `cid:linkedin@${UNIQUE_IDENTIFIER}`,
        github: `cid:github@${UNIQUE_IDENTIFIER}`,
        bluesky: `cid:bluesky@${UNIQUE_IDENTIFIER}`,
        letter: `cid:letter@${UNIQUE_IDENTIFIER}`,
        writeToMe: `cid:write@${UNIQUE_IDENTIFIER}`,
        logo1: `cid:logo1@${UNIQUE_IDENTIFIER}`,
        logo2: `cid:logo2@${UNIQUE_IDENTIFIER}`,
        profilePic: `cid:profile@${UNIQUE_IDENTIFIER}`,
        signature: `cid:signature@${UNIQUE_IDENTIFIER}`,
        message: sender_message
      },
      attachments: getMailAttachments(language, "confirmation")
    };
    const notificationTemplate = sender_language === "da" ? "newMessageDa" : "newMessageEn";
    const mailNotificationOptions = {
      from: `Lars \u{1F468}\u200D\u{1F4BB} Ejaas <${process.env.PRIVATE_EMAIL_USER}>`,
      // this has to be the actual email address as the email client will otherwise rewriting it.
      replyTo: `${sender_name} <${sender_email}>`,
      // Sender's email for replies
      to: process.env.PRIVATE_EMAIL_USER,
      subject: sender_subject,
      template: notificationTemplate,
      context: {
        first_name,
        siteURL: site_url,
        linkedIn: `cid:linkedin@${UNIQUE_IDENTIFIER}`,
        github: `cid:github@${UNIQUE_IDENTIFIER}`,
        bluesky: `cid:bluesky@${UNIQUE_IDENTIFIER}`,
        letter: `cid:letter@${UNIQUE_IDENTIFIER}`,
        writeToMe: `cid:write@${UNIQUE_IDENTIFIER}`,
        logo1: `cid:logo1@${UNIQUE_IDENTIFIER}`,
        logo2: `cid:logo2@${UNIQUE_IDENTIFIER}`,
        profilePic: `cid:profile@${UNIQUE_IDENTIFIER}`,
        signature: `cid:signature@${UNIQUE_IDENTIFIER}`,
        message: sender_message
      },
      attachments: getMailAttachments(language, "notification")
    };
    await Promise.all([
      // send confirmation email to sender
      transporter.sendMail(mailConfirmationOptions),
      // Notification email to receiver
      transporter.sendMail(mailNotificationOptions)
    ]);
    return new Response(
      JSON.stringify({
        message: `Emails ${process.env.NODE_ENV === "production" ? "was" : "would be"} sent successfully. Confirmation sent to ${sender_name} at ${sender_email}`
      }),
      {
        status: 303,
        headers: {
          ...devHeaders,
          Location: redirectUrl
        }
      }
    );
  } catch (error) {
    console.error(error);
    const clientsideError = getErrorMessage(error, language);
    const refererUrl = req.headers.get("referer") || req.headers.get("origin");
    redirectUrl = `${getRedirectUrl(language, refererUrl, "error")}?error=${encodeURIComponent(clientsideError.errorMessage)}&code=${encodeURIComponent(clientsideError.errorCode)}`;
    return new Response(
      JSON.stringify({
        error: clientsideError.errorCode,
        message: clientsideError.errorMessage
      }),
      {
        status: 303,
        headers: {
          ...process.env.NODE_ENV === "development" ? devHeaders : {},
          Location: redirectUrl
        }
      }
    );
  }
};
var config = {
  method: "POST",
  path: FUNCTION_ENDPOINT,
  rateLimit: {
    action: "rate_limit",
    windowSize: 2
  }
};
export {
  config,
  send_email_default as default
};
